
export const Hello = () =>{

    return(
        <div>
            <h5>Welcome to HomePage</h5>
            <p>Hurrryyyyy...!</p>
        </div>
    )
}