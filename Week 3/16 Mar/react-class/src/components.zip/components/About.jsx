
export const About = () =>{

    return(
        <div>
            <h5>My name is: Mugil</h5>
            <p>Age is: 25</p>
        </div>
    )
}